package com.mycompany.userauthsystem;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;

public class UserAuthSystemTest {

    @BeforeAll
    public static void setUpClass() throws Exception {
    }

    @AfterAll
    public static void tearDownClass() throws Exception {
    }

    @BeforeEach
    public void setUp() throws Exception {
    }

    @AfterEach
    public void tearDown() throws Exception {
    }

    @Test
    public void testCheckUserName() {
        assertTrue(UserAuthSystem.checkUserName("Kyl_1"));   // valid
        assertFalse(UserAuthSystem.checkUserName("user"));   // missing _
        assertFalse(UserAuthSystem.checkUserName("longusername")); // too long
    }

    @Test
    public void testCheckPasswordComplexity() {
        assertTrue(UserAuthSystem.checkPasswordComplexity("Ch&&sec@ke99!")); // valid
        assertFalse(UserAuthSystem.checkPasswordComplexity("chelseageag")); // no capital, number, special
        assertFalse(UserAuthSystem.checkPasswordComplexity("Chelseagea7")); // no number, special
        assertFalse(UserAuthSystem.checkPasswordComplexity("Chealseagea7")); // no special char
    }

    @Test
    public void testCheckCellPhoneNumber() {
        assertTrue(UserAuthSystem.checkCellPhoneNumber("+27123456789")); // valid
        assertFalse(UserAuthSystem.checkCellPhoneNumber("0123456789"));  // missing +27
        assertFalse(UserAuthSystem.checkCellPhoneNumber("+2712345678")); // too short
    }

    @Test
    public void testRegisterUser() {
        assertEquals("Username and password successfully captured. User registered!",
                UserAuthSystem.registerUser("user_", "Passw0rd!"));

        assertEquals("Username is not correct. Must have _ and max 5 chars.",
                UserAuthSystem.registerUser("user", "Passw0rd!"));

        assertEquals("Password is not correct. Must have 8+ chars, capital letter, number, and special char.",
                UserAuthSystem.registerUser("user_", "password"));
    }

    @Test
    public void testLoginUser() {
        String storedUsername = "user_";
        String storedPassword = "Passw0rd!";

        assertTrue(UserAuthSystem.loginUser("user_", "Passw0rd!", storedUsername, storedPassword));
        assertFalse(UserAuthSystem.loginUser("wrong", "Passw0rd!", storedUsername, storedPassword));
        assertFalse(UserAuthSystem.loginUser("user_", "wrong", storedUsername, storedPassword));
    }

    @Test
    public void testReturnLoginStatus() {
        assertEquals("Login successful! Welcome back!", UserAuthSystem.returnLoginStatus(true));
        assertEquals("Username or password incorrect, please try again.", UserAuthSystem.returnLoginStatus(false));
    }

    /**
     * Test of main method, of class UserAuthSystem.
     */
    @Test
    public void testMain() {
        System.out.println("main");
        String[] args = null;
        UserAuthSystem.main(args);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
}